﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using ModulTest;


namespace ModulTest

{
    [TestClass]
    public class ModulTest
    {
        [TestMethod]
        public void TestMethod1()
        {
            int a = 10;
            int b = 10;
            int z = a + b;
            Assert.AreEqual(z, 20);
        }
        public void TestMethod2()
        {
            int a = 10;
            int b = 0;
            int z = a + b;
            Assert.AreEqual(z, 10);
        }
        public void TestMethod3()
        {
            int a = 10;
            int b = 13;
            int z = a + b;
            Assert.AreEqual(z, 21);
        }
        public void TestMethod4()
        {
            int a = 10;
            int b = 11;
            int z = a - b;
            Assert.AreEqual(z, 21);
        }
    }
}
